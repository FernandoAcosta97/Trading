<div class="row">

	<!--=====================================
	COLUMNA 1
	======================================-->

	<div class="col-12 col-md-6">

		<!--=====================================
		TARJETA 1
		======================================-->

		<div class="card card-primary card-outline">
			
			<div class="card-header">
				
				<h5 class="m-0">¿Dicta amet facilis rem aperiam at harum?</h5>

				<div class="card-tools">
                
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
            
                </div>

			</div>

			<div class="card-body">

				<video controls class="w-100">
					
					<source src="vistas/videos/cuerpo-activo/01-video.mp4" type="video/mp4">

				</video>

				<h6 class="card-title py-3">Lorem ipsum dolor sit amet</h6>

				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt, esse in, facere at totam exercitationem consequatur minus unde laboriosam officia tenetur magnam quia. Enim, quae, ipsum cupiditate quod provident nihil.</p>

			</div>

		</div>

		<!--=====================================
		TARJETA 2
		======================================-->

		<div class="card card-primary card-outline">

			<div class="card-header">
				
				<h5 class="m-0">Consectetur adipisicing elit</h5>

				<div class="card-tools">
                
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
            
                </div>

			</div>

			<div class="card-body">

				<video controls class="w-100">
					
					<source src="vistas/videos/cuerpo-activo/02-video.mp4" type="video/mp4">

				</video>

				<h6 class="card-title py-3">Quibusdam assumenda sapiente</h6>

				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta laborum rerum qui fugiat sint ipsum. Dolore possimus ut fugiat quibusdam, nam provident consequatur, dolorem obcaecati veniam facilis rerum distinctio repellendus.</p>

				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta laborum rerum qui fugiat sint ipsum. Dolore possimus ut fugiat quibusdam, nam provident consequatur, dolorem obcaecati veniam facilis rerum distinctio repellendus.</p>

			</div>

		</div>

	</div>

	<!--=====================================
	COLUMNA 2
	======================================-->

	<div class="col-12 col-md-6">
		
		<!--=====================================
		TARJETA 1
		======================================-->

		<div class="card card-primary card-outline">

			<div class="card-header">
				
				<h5 class="m-0">Consectetur adipisicing elit</h5>

				<div class="card-tools">
                
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
            
                </div>

			</div>

			<div class="card-body">

				<video controls class="w-100">
					
					<source src="vistas/videos/cuerpo-activo/02-video.mp4" type="video/mp4">

				</video>

				<h6 class="card-title py-3">Quibusdam assumenda sapiente</h6>

				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta laborum rerum qui fugiat sint ipsum. Dolore possimus ut fugiat quibusdam, nam provident consequatur, dolorem obcaecati veniam facilis rerum distinctio repellendus.</p>

				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta laborum rerum qui fugiat sint ipsum. Dolore possimus ut fugiat quibusdam, nam provident consequatur, dolorem obcaecati veniam facilis rerum distinctio repellendus.</p>

			</div>

		</div>

		<!--=====================================
		TARJETA 2
		======================================-->

		<div class="card card-primary card-outline">

			<div class="card-header">
				
				<h5 class="m-0">¿Dicta amet facilis rem aperiam at harum?</h5>

				<div class="card-tools">
                
                  <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
            
                </div>

			</div>

			<div class="card-body">

				<video controls class="w-100">
					
					<source src="vistas/videos/cuerpo-activo/01-video.mp4" type="video/mp4">

				</video>

				<h6 class="card-title py-3">Lorem ipsum dolor sit amet</h6>

				<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt, esse in, facere at totam exercitationem consequatur minus unde laboriosam officia tenetur magnam quia. Enim, quae, ipsum cupiditate quod provident nihil.</p>

			</div>

		</div>

	</div>

</div>